import { useEffect, useState } from "react";
import Head from "next/head";
import Link from "next/link";
import random from "lodash/random";
import DataTable from "@/components/dataTable";
import { SiTwitter, SiDiscord } from "react-icons/si";
import { Wallet } from "@/types/wallet";
import {
  Button,
  Input,
  Container,
  Flex,
  useToast,
  IconButton,
  Heading,
  Text,
  Image,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalBody,
  ModalCloseButton,
  useDisclosure,
} from "@chakra-ui/react";

export default function Home() {
  const [userKey, setUserKey] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const [value, setValue] = useState<number>(0);
  const [isWalletExists, setIsWalletExists] = useState<boolean | null>(null);
  const [topRanks, setTopRanks] = useState<Wallet[]>([]);
  const { isOpen, onOpen, onClose } = useDisclosure();

  const FOXES_EMOJIS = new Array(value).fill("🦊");

  const handleSubmit = async (e: any) => {
    setLoading(true);
    setUserKey("");

    const response = await fetch(`/api/check?key=${userKey}`);
    const { value }: { value: number } = await response.json();

    setValue(value);
    onOpen();

    if (value) {
      setIsWalletExists(true);
    } else {
      setIsWalletExists(false);
    }
    setLoading(false);
  };

  useEffect(() => {
    async function fetchTopRanks() {
      const topRanks = await fetch("/api/top");
      const topRanksResults = await topRanks.json();
      setTopRanks(topRanksResults);
    }
    fetchTopRanks();
  }, []);

  return (
    <Container maxWidth="2xl" centerContent>
      <Head>
        <title>Foxiverse XP Checker</title>
        <meta name="description" content="Foxiverse XP Checker" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <Flex gap={4}>
        <Image
          src="fox-02.png"
          position="absolute"
          top={"-250px"}
          right={0}
          width={"600px"}
          display={["none", "block"]}
          zIndex={-1}
        />
        <Image
          src="fox-01.png"
          position="absolute"
          bottom={0}
          left={"-200px"}
          width={"800px"}
          display={["none", "block"]}
          zIndex={-1}
        />
        <Flex direction="column" gap={4}>
          <DataTable wallets={topRanks} />
          <Flex gap={0}>
            <Input
              borderRadius={0}
              value={userKey}
              onChange={(e) => setUserKey(e.target.value)}
              placeholder="Paste your Wallet"
              size="lg"
              color="orange"
              background="white"
            />
            <Button
              borderRadius={0}
              width={64}
              type="submit"
              bg="orange"
              size="lg"
              color="white"
              onClick={handleSubmit}
              isLoading={loading}
              isDisabled={!userKey}
              fontWeight="hairline"
              fontSize="2xl"
            >
              CHECK
            </Button>
          </Flex>
          <Flex mt={24} gap={8} flexDirection={["column",'row']}>
            <Flex flexDirection="column">
              <Heading as="h6" size="md">
                Welcome to our XP checker!
              </Heading>
              <Text>
                By holding onto Foxis in your wallet, you`ll earn valuable XPs
                every single day. The more Foxis you have, the more XPs you`ll
                accumulate, which means even more $FXV tokens for you to claim
                at launch. But here`s the catch: this incredible opportunity is
                exclusively for our beloved Foxi holders. Please note that any
                roles you have in our discord won`t be reflected on this page.
                Don`t miss out on this chance to level up your earnings and
                secure your financial future. Start accumulating XPs today! XPs
                update every 48h.
              </Text>
            </Flex>
            <Flex gap={6} justifyContent="center" alignItems="center">
              <Link
                legacyBehavior
                href="https://twitter.com/foxiverse_"
                passHref
              >
                <a target="_blank">
                  <SiTwitter size="35px" color="black" />
                </a>
              </Link>

              <Link
                legacyBehavior
                href="https://discord.gg/foxiversenft"
                passHref
              >
                <a target="_blank">
                  <SiDiscord size="35px" color="black" />
                </a>
              </Link>
            </Flex>
          </Flex>
        </Flex>
      </Flex>

      {isWalletExists ? (
        <Modal
          motionPreset="slideInBottom"
          onClose={onClose}
          size="full"
          isOpen={isOpen}
          isCentered
        >
          <ModalOverlay />
          <ModalContent backgroundColor="rgba(0, 0, 0, 0.8)">
            <ModalCloseButton color='white'/>
            <ModalBody
              h="100vh"
              display="flex"
              justifyContent="center"
              alignItems="center"
            >
              <Heading
                as="h1"
                size={["4rem", "12rem"]}
                color="#ff4c00"
                fontSize={["4rem", "12rem"]}
              >
                {value} XP
              </Heading>
              <article>
                {FOXES_EMOJIS.map((fox, i) => (
                  <h5
                    style={{ fontSize: "4rem" }}
                    key={i.toString()}
                    className={`display-${random(1, FOXES_EMOJIS.length - 1)}`}
                  >
                    {fox}
                  </h5>
                ))}
              </article>
            </ModalBody>
          </ModalContent>
        </Modal>
      ) : (
        <Modal
          motionPreset="slideInBottom"
          onClose={onClose}
          size="full"
          isOpen={isOpen}
          isCentered
        >
          <ModalOverlay />
          <ModalContent bg="black">
            <ModalCloseButton color="white" />
            <ModalBody
              h="100vh"
              display="flex"
              justifyContent="center"
              alignItems="center"
            >
              <Flex
                flexDirection={["column", "row"]}
                alignItems="center"
                w="4xl"
              >
                <Image src="fox-03.png" w="lg" />
                <Flex flexDirection="column" gap={4} mt={[8, 2]}>
                  <Heading as="h1" size="4xl" color="#ff4c00">
                    OOPS!
                  </Heading>
                  <Text color="white">
                    Not a Foxi holder? No problem! You can still qualify for the
                    $FXV airdrop by clicking the link below and minting a Foxi.
                    Holding just 1 Foxi makes you eligible for the airdrop,
                    while holding 3 grants you WL access to Foxiverse`s upcoming
                    Land collection.
                  </Text>
                  <Flex justifyContent="flex-end">
                    <Link
                      href="https://souffl3.com/launchpad/foxiverse"
                      target="_blank"
                    >
                      <Button colorScheme="orange">Mint Now</Button>
                    </Link>
                  </Flex>
                </Flex>
              </Flex>
            </ModalBody>
          </ModalContent>
        </Modal>
      )}

      <style jsx global>{`
        body {
          background: url("background.jpg") !important;
          background-size: cover !important;
          background-position: center center !important;
          {/* position: relative; */}
          height: 100vh;

           {
            /* overflow: hidden; */
          }

           {
            /* background: url("fox-02.png"), url("fox-01.png"),
            url("background.jpg") !important;
          background-size: 500px, 500px, cover !important;
          background-position: top right, bottom left, center center !important; */
          }
           {
            /* background-position: top right, -190px 200px, center center !important; */
          }
           {
            /* background-repeat: no-repeat, no-repeat, no-repeat !important; */
          }
        }

        @media screen and (max-width: 768px) {
          body {
            background: url("background.jpg") !important;
            background-size: cover !important;
            background-position: center center !important;
            background-repeat: no-repeat !important;
          }
        }

        article {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          overflow: hidden;
          z-index: -1;
        }

        article h5 {
          position: absolute;
          display: block;
          list-style: none;
          width: 20px;
          height: 20px;
          animation: animate 25s linear infinite;
          top: -150px;
        }

        article h5:nth-child(1) {
          left: 25%;
          width: 80px;
          height: 80px;
          animation-delay: 0s;
        }

        article h5:nth-child(2) {
          left: 10%;
          width: 20px;
          height: 20px;
          animation-delay: 2s;
          animation-duration: 12s;
        }

        article h5:nth-child(3) {
          left: 70%;
          width: 20px;
          height: 20px;
          animation-delay: 4s;
        }

        article h5:nth-child(4) {
          left: 40%;
          width: 60px;
          height: 60px;
          animation-delay: 0s;
          animation-duration: 18s;
        }

        article h5:nth-child(5) {
          left: 65%;
          width: 20px;
          height: 20px;
          animation-delay: 0s;
        }

        article h5:nth-child(6) {
          left: 75%;
          width: 110px;
          height: 110px;
          animation-delay: 3s;
        }

        article h5:nth-child(7) {
          left: 35%;
          width: 150px;
          height: 150px;
          animation-delay: 7s;
        }

        article h5:nth-child(8) {
          left: 50%;
          width: 25px;
          height: 25px;
          animation-delay: 15s;
          animation-duration: 45s;
        }

        article h5:nth-child(9) {
          left: 20%;
          width: 15px;
          height: 15px;
          animation-delay: 2s;
          animation-duration: 35s;
        }

        article h5:nth-child(10) {
          left: 85%;
          width: 150px;
          height: 150px;
          animation-delay: 0s;
          animation-duration: 11s;
        }

        @keyframes animate {
          0% {
            transform: translateY(0) rotate(0deg);
            opacity: 1;
            border-radius: 0;
          }

          100% {
            transform: translateY(1000px) rotate(720deg);
            opacity: 0;
            border-radius: 50%;
          }
        }
      `}</style>
    </Container>
  );
}
