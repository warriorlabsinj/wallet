export interface Wallet {
    [key: string]: number;
  }
  