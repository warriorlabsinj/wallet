import { Wallet } from "@/types/wallet";
import {
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  TableContainer,
} from "@chakra-ui/react";

export default function DataTable({ wallets }: { wallets: Wallet[] }) {
  return (
    <TableContainer fontSize="1.8rem" width={["xs", "100%"]}>
      <Table variant="unstyled" bg="black" color="white">
        <Thead color="black" bg="#ff4c00">
          <Tr>
            <Th fontSize="xl" fontWeight="light" textAlign="center">
              Rank
            </Th>
            <Th
              borderLeft="black solid 1px"
              fontSize="xl"
              fontWeight="light"
              textAlign="center"
            >
              Wallet
            </Th>
            <Th
              borderLeft="black solid 1px"
              fontSize="xl"
              fontWeight="light"
              textAlign="center"
              isNumeric
            >
              XP
            </Th>
            <Th
              borderLeft="black solid 1px"
              fontSize="xl"
              fontWeight="light"
              textAlign="center"
            >
              $FXV
            </Th>
          </Tr>
        </Thead>
        <Tbody>
          {wallets.slice(0, 5).map((w: Wallet, i) => (
            <Tr key={i}>
              <Td
                borderRight="#ff4c00 solid 1px"
                borderBottom="#ff4c00 solid 1px"
                textAlign="center"
              >
                {i + 1}
              </Td>
              <Td border="#ff4c00 solid 1px" textAlign="center">
                {`${Object.keys(w).toString().slice(0, 4)}...${Object.keys(w)
                  .toString()
                  .slice(-4)}`}
              </Td>
              <Td border="#ff4c00 solid 1px" isNumeric textAlign="center">
                {Object.values(w)}
              </Td>
              <Td
                borderBottom="#ff4c00 solid 1px"
                borderLeft="#ff4c00 solid 1px"
                isNumeric
                textAlign="center"
              >
                ?
              </Td>
            </Tr>
          ))}
        </Tbody>
      </Table>
    </TableContainer>
  );
}
