import { Flex, Image, Heading, Text } from "@chakra-ui/react";
import Link from "next/link";
import { PropsWithChildren } from "react";

export default function Layout({ children }: PropsWithChildren) {
  return (
    <>
      <Flex>
        <Link href="https://foxiverse.xyz/">
          <Image src="/logo-dark.png" width={"15rem"} />
        </Link>
      </Flex>
      <main>{children}</main>
     
    </>
  );
}
